module.exports = {
  apps: [
    {
      name: 'jdc',
      script: './app.js',
    },
  ],
};
